clear all 
%%
%filenum�͕ύX���Ȃ�
%���摜��left1,2,3,...,�E�摜��1,2,3,....���Ɛݒ�
%calib_gui�͉E�����玞�v���
%1024*768�T�C�Y�p
filenum = 3;
patternSize = [7,5];
imgHSfn = 'left%d.bmp'; %���S
imgHDfn = 'right%d.bmp';
load Calib_Results_stereo.mat

%AL=[fc_left(1) 0 cc_left(1); 0 fc_left(2) cc_left(2); 0 0 1];
%AR=[fc_right(1) 0 cc_right(1); 0 fc_right(2) cc_right(2); 0 0 1];
save('AL.dat', 'KK_left','-ascii');
save('AR.dat', 'KK_right','-ascii');
save('kc_left.dat', 'kc_left','-ascii');
save('kc_right.dat', 'kc_right','-ascii');

Tr=[0 -T(3) T(2); T(3) 0 -T(1); -T(2) T(1) 0];
save('Rr.dat', 'R','-ascii');
save('tr.dat', 'Tr','-ascii');


%% �蓮
corners = cell(filenum,2);

%% left 
calib_gui 
%�E�����玞�v���
%%
for i=1:filenum
    corners{i,1} = eval(['x_' num2str(i)]);
end

%% right
calib_gui 
%%
for i=1:filenum
    corners{i,2} = eval(['x_' num2str(i)]);
end

%%
X_1 = stereo_triangulation([corners{:,1}],[corners{:,2}],om,T,...
                          fc_left,cc_left,kc_left,0,...
                          fc_right,cc_right,kc_right,0);
                      

 x_1 = zeros(2,35);
for i=1:7
    for j=1:5
        x_1(:,j + (i-1)*5) = [192+80*i, 624-80*j];
    end
end
t=  x_1;
% x_2 = x_1;
% x_3 = x_1;
x_1 = [t,t,t];

n_ima = 1;

% Image size: (may or may not be available)

nx = 1024;
ny = 768;

% No calibration image is available (only the corner coordinates)

no_image = 1;

% Set the toolbox not to prompt the user (choose default values)

dont_ask = 1;

% Run the main calibration routine:

go_calib_optim;

% Shows the extrinsic parameters:

ext_calib;

% Reprojection on the original images:

%reproject_calib;

% Set the toolbox to normal mode of operation again:

dont_ask =  0;

%KK_p = KK;
%kc_p = kc;
%AP=[fc(1) 0 cc(1); 0 fc(2) cc(2); 0 0 1];
T_kk=[0 -Tc_kk(3) Tc_kk(2); Tc_kk(3) 0 -Tc_kk(1); -Tc_kk(2) Tc_kk(1) 0];

save('AP.dat', 'KK','-ascii');
save('kc_pro.dat', 'kc','-ascii');
save('Rp.dat', 'R_kk','-ascii');
save('tp.dat', 'T_kk','-ascii');

