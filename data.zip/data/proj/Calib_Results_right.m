% Intrinsic and Extrinsic Camera Parameters
%
% This script file can be directly excecuted under Matlab to recover the camera intrinsic and extrinsic parameters.
% IMPORTANT: This file contains neither the structure of the calibration objects nor the image coordinates of the calibration points.
%            All those complementary variables are saved in the complete matlab data file Calib_Results.mat.
% For more information regarding the calibration model visit http://www.vision.caltech.edu/bouguetj/calib_doc/


%-- Focal length:
fc = [ 1139.653515155095000 ; 1139.616878993664200 ];

%-- Principal point:
cc = [ 329.964201109267890 ; 251.919135805481290 ];

%-- Skew coefficient:
alpha_c = 0.000000000000000;

%-- Distortion coefficients:
kc = [ -0.092331959786026 ; 0.364089088663250 ; 0.000175835471471 ; 0.003424188420500 ; 0.000000000000000 ];

%-- Focal length uncertainty:
fc_error = [ 8.894772063618188 ; 8.285328754612177 ];

%-- Principal point uncertainty:
cc_error = [ 13.686463608063470 ; 11.834307171404770 ];

%-- Skew coefficient uncertainty:
alpha_c_error = 0.000000000000000;

%-- Distortion coefficients uncertainty:
kc_error = [ 0.044413939921226 ; 0.500199172666519 ; 0.003306113253259 ; 0.003792621317610 ; 0.000000000000000 ];

%-- Image size:
nx = 648;
ny = 488;


%-- Various other variables (may be ignored if you do not use the Matlab Calibration Toolbox):
%-- Those variables are used to control which intrinsic parameters should be optimized

n_ima = 21;						% Number of calibration images
est_fc = [ 1 ; 1 ];					% Estimation indicator of the two focal variables
est_aspect_ratio = 1;				% Estimation indicator of the aspect ratio fc(2)/fc(1)
center_optim = 1;					% Estimation indicator of the principal point
est_alpha = 0;						% Estimation indicator of the skew coefficient
est_dist = [ 1 ; 1 ; 1 ; 1 ; 0 ];	% Estimation indicator of the distortion coefficients


%-- Extrinsic parameters:
%-- The rotation (omc_kk) and the translation (Tc_kk) vectors for every calibration image and their uncertainties

%-- Image #1:
omc_1 = [ 2.956932e+00 ; 1.210955e-01 ; 1.600875e-01 ];
Tc_1  = [ 1.504242e+01 ; 1.355144e+02 ; 1.136030e+03 ];
omc_error_1 = [ 1.162538e-02 ; 2.176592e-03 ; 1.929136e-02 ];
Tc_error_1  = [ 1.367683e+01 ; 1.178668e+01 ; 8.581945e+00 ];

%-- Image #2:
omc_2 = [ 2.507259e+00 ; 1.026256e-03 ; 2.275728e-01 ];
Tc_2  = [ 9.187122e+00 ; 1.310822e+02 ; 1.138456e+03 ];
omc_error_2 = [ 1.005125e-02 ; 5.155216e-03 ; 1.499273e-02 ];
Tc_error_2  = [ 1.371535e+01 ; 1.187377e+01 ; 9.148589e+00 ];

%-- Image #3:
omc_3 = [ 2.908963e+00 ; 9.010216e-02 ; -7.701098e-01 ];
Tc_3  = [ 7.609058e+01 ; 1.451167e+02 ; 1.423196e+03 ];
omc_error_3 = [ 1.107232e-02 ; 3.541626e-03 ; 1.865479e-02 ];
Tc_error_3  = [ 1.714333e+01 ; 1.479893e+01 ; 9.960769e+00 ];

%-- Image #4:
omc_4 = [ 2.787248e+00 ; 1.181750e-01 ; 1.987498e-01 ];
Tc_4  = [ -8.124379e+01 ; 1.479784e+02 ; 1.450429e+03 ];
omc_error_4 = [ 1.065734e-02 ; 3.077671e-03 ; 1.672567e-02 ];
Tc_error_4  = [ 1.749770e+01 ; 1.514129e+01 ; 1.128605e+01 ];

%-- Image #5:
omc_5 = [ 2.434503e+00 ; 1.404509e-01 ; 9.640556e-01 ];
Tc_5  = [ -1.827188e+01 ; 1.007346e+02 ; 1.209525e+03 ];
omc_error_5 = [ 1.053069e-02 ; 6.817058e-03 ; 1.494179e-02 ];
Tc_error_5  = [ 1.456638e+01 ; 1.258216e+01 ; 9.670793e+00 ];

%-- Image #6:
omc_6 = [ 2.909470e+00 ; 7.968455e-02 ; -9.276816e-02 ];
Tc_6  = [ -5.223655e+01 ; 1.428791e+02 ; 1.429052e+03 ];
omc_error_6 = [ 1.282573e-02 ; 2.006950e-03 ; 1.915887e-02 ];
Tc_error_6  = [ 1.721409e+01 ; 1.492086e+01 ; 1.127084e+01 ];

%-- Image #7:
omc_7 = [ -2.663971e+00 ; -3.974587e-01 ; 5.377640e-01 ];
Tc_7  = [ 9.484262e+00 ; 1.467577e+00 ; 1.473026e+03 ];
omc_error_7 = [ 1.064376e-02 ; 3.754107e-03 ; 1.783350e-02 ];
Tc_error_7  = [ 1.769049e+01 ; 1.526590e+01 ; 1.029268e+01 ];

%-- Image #8:
omc_8 = [ -2.822105e+00 ; -2.425232e-01 ; -9.917892e-01 ];
Tc_8  = [ 1.295253e+01 ; 1.030664e+02 ; 1.112458e+03 ];
omc_error_8 = [ 1.136020e-02 ; 6.601942e-03 ; 1.741743e-02 ];
Tc_error_8  = [ 1.337801e+01 ; 1.154461e+01 ; 8.311194e+00 ];

%-- Image #9:
omc_9 = [ 2.923111e+00 ; 2.092316e-02 ; 2.084118e-01 ];
Tc_9  = [ -1.606054e+01 ; 1.224718e+02 ; 1.507846e+03 ];
omc_error_9 = [ 1.175265e-02 ; 2.653881e-03 ; 1.898798e-02 ];
Tc_error_9  = [ 1.813733e+01 ; 1.567263e+01 ; 1.145733e+01 ];

%-- Image #10:
omc_10 = [ 3.075545e+00 ; -2.403859e-02 ; 5.526652e-01 ];
Tc_10  = [ 2.415617e+01 ; 1.379137e+02 ; 1.087403e+03 ];
omc_error_10 = [ 1.094677e-02 ; 3.977948e-03 ; 1.959610e-02 ];
Tc_error_10  = [ 1.309427e+01 ; 1.128148e+01 ; 8.060570e+00 ];

%-- Image #11:
omc_11 = [ -3.005229e+00 ; -8.737557e-02 ; 8.120106e-01 ];
Tc_11  = [ 1.775334e+01 ; 1.452166e+02 ; 1.503193e+03 ];
omc_error_11 = [ 1.074070e-02 ; 3.693845e-03 ; 2.036616e-02 ];
Tc_error_11  = [ 1.809834e+01 ; 1.559646e+01 ; 1.035967e+01 ];

%-- Image #12:
omc_12 = [ -2.381603e+00 ; -6.936140e-02 ; 1.022093e+00 ];
Tc_12  = [ 1.145415e+02 ; 6.015447e+01 ; 1.630760e+03 ];
omc_error_12 = [ 1.084088e-02 ; 6.697763e-03 ; 1.532196e-02 ];
Tc_error_12  = [ 1.959014e+01 ; 1.694618e+01 ; 1.125212e+01 ];

%-- Image #13:
omc_13 = [ 2.656150e+00 ; 7.847983e-02 ; 1.990351e-02 ];
Tc_13  = [ -1.922800e+01 ; 1.781038e+02 ; 1.415682e+03 ];
omc_error_13 = [ 1.026311e-02 ; 3.656504e-03 ; 1.572963e-02 ];
Tc_error_13  = [ 1.708248e+01 ; 1.480576e+01 ; 1.117505e+01 ];

%-- Image #14:
omc_14 = [ 2.419881e+00 ; 1.532986e-01 ; 4.373640e-01 ];
Tc_14  = [ -1.557058e+01 ; 1.596098e+02 ; 1.343691e+03 ];
omc_error_14 = [ 1.000313e-02 ; 5.647522e-03 ; 1.450556e-02 ];
Tc_error_14  = [ 1.621319e+01 ; 1.402578e+01 ; 1.078721e+01 ];

%-- Image #15:
omc_15 = [ 2.753762e+00 ; 3.329862e-01 ; -4.328369e-01 ];
Tc_15  = [ 5.635895e+01 ; 1.410044e+02 ; 1.622238e+03 ];
omc_error_15 = [ 1.068030e-02 ; 3.466226e-03 ; 1.766738e-02 ];
Tc_error_15  = [ 1.952437e+01 ; 1.691096e+01 ; 1.225642e+01 ];

%-- Image #16:
omc_16 = [ 2.764587e+00 ; 1.691628e-01 ; 7.526981e-02 ];
Tc_16  = [ 8.964785e+01 ; 1.687615e+02 ; 1.601507e+03 ];
omc_error_16 = [ 1.127979e-02 ; 3.197354e-03 ; 1.751635e-02 ];
Tc_error_16  = [ 1.926154e+01 ; 1.667880e+01 ; 1.267345e+01 ];

%-- Image #17:
omc_17 = [ 2.337851e+00 ; -1.423790e-01 ; 4.844131e-01 ];
Tc_17  = [ 3.523992e+01 ; 1.842747e+02 ; 1.314180e+03 ];
omc_error_17 = [ 9.762187e-03 ; 6.575908e-03 ; 1.401368e-02 ];
Tc_error_17  = [ 1.586077e+01 ; 1.375525e+01 ; 1.084636e+01 ];

%-- Image #18:
omc_18 = [ 2.760589e+00 ; -1.196143e-01 ; -5.338772e-01 ];
Tc_18  = [ 1.378499e+02 ; 2.593606e+02 ; 1.780321e+03 ];
omc_error_18 = [ 1.092187e-02 ; 2.990598e-03 ; 1.813053e-02 ];
Tc_error_18  = [ 2.154261e+01 ; 1.865415e+01 ; 1.335578e+01 ];

%-- Image #19:
omc_19 = [ 2.598170e+00 ; 1.272497e-01 ; 1.793199e-01 ];
Tc_19  = [ -2.340185e+02 ; 1.748763e+02 ; 1.445686e+03 ];
omc_error_19 = [ 1.008153e-02 ; 4.141665e-03 ; 1.585048e-02 ];
Tc_error_19  = [ 1.746830e+01 ; 1.530458e+01 ; 1.251467e+01 ];

%-- Image #20:
omc_20 = [ 2.287430e+00 ; 2.384097e-01 ; 1.094086e+00 ];
Tc_20  = [ 3.358761e+01 ; 1.068621e+02 ; 9.864408e+02 ];
omc_error_20 = [ 1.075955e-02 ; 7.589173e-03 ; 1.441869e-02 ];
Tc_error_20  = [ 1.187810e+01 ; 1.026979e+01 ; 8.237905e+00 ];

%-- Image #21:
omc_21 = [ 2.966239e+00 ; 2.845173e-01 ; 4.262817e-01 ];
Tc_21  = [ -2.643852e+01 ; 1.439936e+02 ; 1.107792e+03 ];
omc_error_21 = [ 1.095370e-02 ; 2.387869e-03 ; 1.866950e-02 ];
Tc_error_21  = [ 1.337307e+01 ; 1.148630e+01 ; 8.318666e+00 ];

