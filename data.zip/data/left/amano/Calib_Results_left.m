% Intrinsic and Extrinsic Camera Parameters
%
% This script file can be directly excecuted under Matlab to recover the camera intrinsic and extrinsic parameters.
% IMPORTANT: This file contains neither the structure of the calibration objects nor the image coordinates of the calibration points.
%            All those complementary variables are saved in the complete matlab data file Calib_Results.mat.
% For more information regarding the calibration model visit http://www.vision.caltech.edu/bouguetj/calib_doc/


%-- Focal length:
fc = [ 1287.859875851845100 ; 1294.887367283322600 ];

%-- Principal point:
cc = [ 354.401338673749760 ; 327.284499823719100 ];

%-- Skew coefficient:
alpha_c = 0.000000000000000;

%-- Distortion coefficients:
kc = [ -0.123464517149705 ; -1.843395258417433 ; 0.008947574135126 ; -0.003339121572818 ; 0.000000000000000 ];

%-- Focal length uncertainty:
fc_error = [ 34.981137917119149 ; 34.862001017257484 ];

%-- Principal point uncertainty:
cc_error = [ 33.515290167606899 ; 41.990059298518339 ];

%-- Skew coefficient uncertainty:
alpha_c_error = 0.000000000000000;

%-- Distortion coefficients uncertainty:
kc_error = [ 0.159413262818847 ; 2.477410051550586 ; 0.007603626503619 ; 0.005627941319883 ; 0.000000000000000 ];

%-- Image size:
nx = 640;
ny = 480;


%-- Various other variables (may be ignored if you do not use the Matlab Calibration Toolbox):
%-- Those variables are used to control which intrinsic parameters should be optimized

n_ima = 21;						% Number of calibration images
est_fc = [ 1 ; 1 ];					% Estimation indicator of the two focal variables
est_aspect_ratio = 1;				% Estimation indicator of the aspect ratio fc(2)/fc(1)
center_optim = 1;					% Estimation indicator of the principal point
est_alpha = 0;						% Estimation indicator of the skew coefficient
est_dist = [ 1 ; 1 ; 1 ; 1 ; 0 ];	% Estimation indicator of the distortion coefficients


%-- Extrinsic parameters:
%-- The rotation (omc_kk) and the translation (Tc_kk) vectors for every calibration image and their uncertainties

%-- Image #1:
omc_1 = [ 3.029883e+00 ; 1.647045e-01 ; -1.598859e-01 ];
Tc_1  = [ -1.765032e+02 ; -1.011203e+01 ; 1.181400e+03 ];
omc_error_1 = [ 3.541998e-02 ; 6.286718e-03 ; 5.133529e-02 ];
Tc_error_1  = [ 3.079078e+01 ; 3.838497e+01 ; 3.329213e+01 ];

%-- Image #2:
omc_2 = [ 2.584487e+00 ; 9.759108e-02 ; -3.822623e-02 ];
Tc_2  = [ -1.822273e+02 ; -1.511133e+01 ; 1.182572e+03 ];
omc_error_2 = [ 3.213686e-02 ; 1.087894e-02 ; 3.726286e-02 ];
Tc_error_2  = [ 3.075967e+01 ; 3.845676e+01 ; 3.444781e+01 ];

%-- Image #3:
omc_3 = [ 2.875814e+00 ; 1.549874e-01 ; -1.087738e+00 ];
Tc_3  = [ -5.666327e+01 ; -1.840634e+01 ; 1.448225e+03 ];
omc_error_3 = [ 3.576928e-02 ; 1.861274e-02 ; 3.735054e-02 ];
Tc_error_3  = [ 3.764574e+01 ; 4.693647e+01 ; 3.692123e+01 ];

%-- Image #4:
omc_4 = [ 2.863044e+00 ; 1.791729e-01 ; -8.403259e-02 ];
Tc_4  = [ -2.066959e+02 ; -2.019577e+01 ; 1.505604e+03 ];
omc_error_4 = [ 3.364340e-02 ; 7.719422e-03 ; 4.701745e-02 ];
Tc_error_4  = [ 3.920940e+01 ; 4.893555e+01 ; 4.285824e+01 ];

%-- Image #5:
omc_5 = [ 2.598419e+00 ; 1.997210e-01 ; 7.221734e-01 ];
Tc_5  = [ -1.934451e+02 ; -5.106727e+01 ; 1.257538e+03 ];
omc_error_5 = [ 3.087618e-02 ; 1.507920e-02 ; 3.874937e-02 ];
Tc_error_5  = [ 3.262195e+01 ; 4.090005e+01 ; 3.784980e+01 ];

%-- Image #6:
omc_6 = [ 2.951477e+00 ; 1.392621e-01 ; -4.019799e-01 ];
Tc_6  = [ -1.810060e+02 ; -2.458489e+01 ; 1.483265e+03 ];
omc_error_6 = [ 3.544120e-02 ; 9.497682e-03 ; 4.491991e-02 ];
Tc_error_6  = [ 3.866861e+01 ; 4.818027e+01 ; 4.058415e+01 ];

%-- Image #7:
omc_7 = [ -2.505957e+00 ; -3.595679e-01 ; 7.866295e-01 ];
Tc_7  = [ -1.106922e+02 ; -1.664839e+02 ; 1.499359e+03 ];
omc_error_7 = [ 3.072908e-02 ; 1.389097e-02 ; 3.904048e-02 ];
Tc_error_7  = [ 3.917167e+01 ; 4.863613e+01 ; 3.944655e+01 ];

%-- Image #8:
omc_8 = [ -2.790490e+00 ; -1.806902e-01 ; -6.643701e-01 ];
Tc_8  = [ -1.836001e+02 ; -3.766340e+01 ; 1.156021e+03 ];
omc_error_8 = [ 3.482339e-02 ; 1.131280e-02 ; 3.720891e-02 ];
Tc_error_8  = [ 3.025604e+01 ; 3.763275e+01 ; 3.273210e+01 ];

%-- Image #9:
omc_9 = [ 2.992242e+00 ; 5.871966e-02 ; -1.122522e-01 ];
Tc_9  = [ -1.291909e+02 ; -4.870609e+01 ; 1.546222e+03 ];
omc_error_9 = [ 3.858632e-02 ; 6.455788e-03 ; 5.361221e-02 ];
Tc_error_9  = [ 4.025537e+01 ; 5.009879e+01 ; 4.324228e+01 ];

%-- Image #10:
omc_10 = [ -3.086864e+00 ; 2.056869e-02 ; -1.912581e-01 ];
Tc_10  = [ -1.782073e+02 ; -4.388367e+00 ; 1.135375e+03 ];
omc_error_10 = [ 4.092466e-02 ; 4.583827e-03 ; 6.178815e-02 ];
Tc_error_10  = [ 2.953636e+01 ; 3.693620e+01 ; 3.236016e+01 ];

%-- Image #11:
omc_11 = [ -2.835931e+00 ; -1.236040e-01 ; 1.090402e+00 ];
Tc_11  = [ -9.775236e+01 ; -2.567196e+01 ; 1.540411e+03 ];
omc_error_11 = [ 2.882440e-02 ; 1.749435e-02 ; 4.296980e-02 ];
Tc_error_11  = [ 4.004599e+01 ; 4.998939e+01 ; 3.900984e+01 ];

%-- Image #12:
omc_12 = [ -2.196971e+00 ; -3.500263e-02 ; 1.249034e+00 ];
Tc_12  = [ 2.554390e+01 ; -1.168408e+02 ; 1.636514e+03 ];
omc_error_12 = [ 2.919477e-02 ; 2.348251e-02 ; 3.302487e-02 ];
Tc_error_12  = [ 4.266883e+01 ; 5.315405e+01 ; 4.084653e+01 ];

%-- Image #13:
omc_13 = [ 2.716411e+00 ; 1.609573e-01 ; -2.962388e-01 ];
Tc_13  = [ -1.504344e+02 ; 1.346276e+01 ; 1.452821e+03 ];
omc_error_13 = [ 3.284445e-02 ; 9.661117e-03 ; 3.932705e-02 ];
Tc_error_13  = [ 3.780925e+01 ; 4.715496e+01 ; 4.047083e+01 ];

%-- Image #14:
omc_14 = [ 2.523230e+00 ; 2.483883e-01 ; 1.883384e-01 ];
Tc_14  = [ -1.629150e+02 ; -1.453297e+00 ; 1.389516e+03 ];
omc_error_14 = [ 3.123636e-02 ; 1.169225e-02 ; 3.724879e-02 ];
Tc_error_14  = [ 3.609957e+01 ; 4.511186e+01 ; 4.025133e+01 ];

%-- Image #15:
omc_15 = [ 2.765266e+00 ; 4.219652e-01 ; -7.230001e-01 ];
Tc_15  = [ -3.512629e+01 ; -3.798176e+01 ; 1.639407e+03 ];
omc_error_15 = [ 3.382984e-02 ; 1.463636e-02 ; 4.057239e-02 ];
Tc_error_15  = [ 4.268261e+01 ; 5.305553e+01 ; 4.428955e+01 ];

%-- Image #16:
omc_16 = [ 2.818147e+00 ; 2.424445e-01 ; -2.194885e-01 ];
Tc_16  = [ -6.839369e+00 ; -9.180551e+00 ; 1.609170e+03 ];
omc_error_16 = [ 3.438157e-02 ; 8.080477e-03 ; 4.729989e-02 ];
Tc_error_16  = [ 4.189251e+01 ; 5.208445e+01 ; 4.636436e+01 ];

%-- Image #17:
omc_17 = [ 2.435374e+00 ; -4.843345e-02 ; 2.307695e-01 ];
Tc_17  = [ -1.209348e+02 ; 2.778199e+01 ; 1.349779e+03 ];
omc_error_17 = [ 3.137210e-02 ; 1.380312e-02 ; 3.424169e-02 ];
Tc_error_17  = [ 3.505577e+01 ; 4.382360e+01 ; 3.932923e+01 ];

%-- Image #18:
omc_18 = [ 2.740616e+00 ; -3.539946e-02 ; -8.289743e-01 ];
Tc_18  = [ 7.941186e+01 ; 6.994001e+01 ; 1.785756e+03 ];
omc_error_18 = [ 3.688447e-02 ; 1.239330e-02 ; 3.745650e-02 ];
Tc_error_18  = [ 4.635106e+01 ; 5.790743e+01 ; 4.811456e+01 ];

%-- Image #19:
omc_19 = [ 2.680523e+00 ; 2.200565e-01 ; -7.582816e-02 ];
Tc_19  = [ -3.561357e+02 ; 9.796971e-01 ; 1.542745e+03 ];
omc_error_19 = [ 3.345560e-02 ; 1.078174e-02 ; 4.294582e-02 ];
Tc_error_19  = [ 4.000939e+01 ; 5.060772e+01 ; 4.820962e+01 ];

%-- Image #20:
omc_20 = [ 2.470014e+00 ; 3.034384e-01 ; 8.723267e-01 ];
Tc_20  = [ -1.896852e+02 ; -2.848113e+01 ; 1.030879e+03 ];
omc_error_20 = [ 3.020096e-02 ; 1.674706e-02 ; 3.677452e-02 ];
Tc_error_20  = [ 2.676874e+01 ; 3.359927e+01 ; 3.213696e+01 ];

%-- Image #21:
omc_21 = [ 3.059017e+00 ; 3.070779e-01 ; 1.833323e-01 ];
Tc_21  = [ -2.221385e+02 ; -3.883959e-01 ; 1.160097e+03 ];
omc_error_21 = [ 3.739337e-02 ; 6.648501e-03 ; 6.134041e-02 ];
Tc_error_21  = [ 3.011114e+01 ; 3.785061e+01 ; 3.419873e+01 ];

